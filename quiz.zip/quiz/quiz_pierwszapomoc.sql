-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Maj 27, 2025 at 11:54 PM
-- Wersja serwera: 10.4.32-MariaDB
-- Wersja PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `quiz_pierwszapomoc`
--

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `quiz_questions`
--

CREATE TABLE `quiz_questions` (
  `id` int(11) NOT NULL,
  `question` text NOT NULL,
  `answer_a` text DEFAULT NULL,
  `answer_b` text DEFAULT NULL,
  `answer_c` text DEFAULT NULL,
  `answer_d` text DEFAULT NULL,
  `correct_answer` char(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `quiz_questions`
--

INSERT INTO `quiz_questions` (`id`, `question`, `answer_a`, `answer_b`, `answer_c`, `answer_d`, `correct_answer`) VALUES
(1, 'Obowiązek udzielenia pomocy ofiarom wypadku dotyczy:', 'wszystkich, ponieważ zawsze można wykonać część zadań ratunkowych', 'tylko osób, które mają przygotowanie medyczne', 'wszystkich, ale za popełnione błędy zawsze grozi odpowiedzialność karna', NULL, 'A'),
(2, 'Przy udzielaniu rannym pierwszej pomocy na miejscu wypadku należy przede wszystkim:', 'udzielić pomocy tym, których stan zagraża życiu', 'podać rannym leki uspokajające', 'pojechać po lekarza', NULL, 'A'),
(3, 'Świadek wypadku, w którym są ofiary, w pierwszej kolejności powinien:', 'zabezpieczyć miejsce wypadku,', 'zapisać świadków wypadku,', 'udzielić pierwszej pomocy.', NULL, 'A'),
(4, 'Jeżeli ofiara wypadku po kilku minutach odzyskała przytomność i chce iść do domu, to należy:', 'namawiać ją do pozostania i wezwać pomoc medyczną', 'podać jej coś do picia i środki przeciwbólowe', 'pozwolić jej iść do domu, zalecając wizytę u lekarza', NULL, 'A'),
(5, 'Aby wezwać pomoc z telefonu komórkowego, należy zadzwonić pod numer alarmowy:', '999', '112', '998', NULL, 'B'),
(6, 'Brak krążenia krwi u osoby dorosłej, nieprzytomnej można rozpoznać po:', 'braku tętna na tętnicy szyjnej', 'bólu w klatce piersiowej', 'braku oddechu', NULL, 'C'),
(7, 'Dokonując oceny wstępnej osoby poszkodowanej sprawdzisz kolejno', 'stan świadomości, ogólne wrażenie, drożność dróg oddechowych, oddech', 'drożność dróg oddechowych, oddech, krążenie, stan świadomości', 'ogólne wrażenie, stan świadomości, drożność dróg oddechowych, oddech', NULL, 'C'),
(8, 'Jak długo powinna trwać ocena oddechu u osoby nieprzytomnej?', 'około 5sek', 'około 10sek', 'około 15sek', NULL, 'B'),
(9, 'Ocena oddychania u osoby nieprzytomnej wymaga:', 'badania słuchem, wzrokiem lub z pomocą lusterka', 'zastosowania rękoczynu czoło-żuchwa', 'zastosowania chwytu Rauteka', NULL, 'B'),
(10, 'Poszkodowanego, który jest nieprzytomny, ale oddycha należy ułożyć:', 'na brzuchu z ręką pod głową', 'na plecach', 'w pozycji bezpiecznej.', NULL, 'C'),
(11, 'Jeżeli poszkodowany leży dłuższy czas w pozycji bocznej bezpiecznej, należy odwrócić go na drugi bok po upływie:', '15 minut', '30 minut', '60 minut', NULL, 'B'),
(12, 'Bezpośrednio po stwierdzeniu u dziecka braku oddechu należy:', 'ocenić krążenie i zadzwonić po ambulans', 'wezwać pomoc okrzykiem', 'wykonać 5 skutecznych oddechów zastępczych', NULL, 'C'),
(13, 'Pośredni masaż serca:', 'należy przerwać zawsze po upływie 2 min na 5-10 sek aby sprawdzić tętno', 'u dorosłych powinien być prowadzony w proporcji 15 : 2', 'musi być rozpoczęty po stwierdzeniu braku przytomności i prawidłowego oddechu', NULL, 'C'),
(14, 'Podczas 1 cyklu resuscytacji u osoby dorosłej należy wykonać:', '20 : 2', '30 : 2', '30 : 5', NULL, 'B'),
(15, 'Zalecany stosunek oddechów do uciśnięć klatki piersiowej u dziecka wynosi:', '2 : 15', '5 :15', '2 : 30', NULL, 'C'),
(16, 'Jaka powinna być częstotliwość uciśnięć klatki piersiowej w trakcie przeprowadzania reanimacji?', '80 - 90 razy na minutę', '100 - 120 razy na minute', 'do 150 razy na minute', NULL, 'B'),
(17, 'Omdlenie mija najszybciej, gdy poszkodowany:', 'leży na plecach z uniesionymi rękami i nogami', 'leży na boku', 'znajduje się w pozycji półsiedzącej', NULL, 'A'),
(18, 'Która z wymienionych przyczyn jest najczęstszym powodem niedrożności dróg oddechowych u osób dorosłych?', 'uraz krtani i tchawicy', 'zaleganie wydzieliny', 'utrata przytomności', NULL, 'C'),
(19, 'Pierwsza pomoc w przypadku oparzeń powinna polegać na:', 'polewaniu oparzonego miejsca zimną wodą', 'polewaniu oparzonego miejsca ciepłą wodą', 'smarowaniu oparzonego miejsca maścią', NULL, 'A'),
(20, 'W przypadku poparzenia dłoni należy w pierwszej kolejności:', 'posmarować dłoń kremem', 'zdjąć pierścionki i obrączki', 'zdezynfekować', NULL, 'B'),
(21, 'W przypadku oparzenia nie należy:', 'chłodzić rany oparzeniowej', 'przebijać pęcherzy', 'zakładać opatrunku', NULL, 'B'),
(22, 'Przy złamaniu kości przedramienia należy:', 'podać poszkodowanemu środki przeciwbólowe', 'unieruchomić dwa sąsiadujące ze sobą stawy', 'nie ruszać poszkodowanego do czasu przyjazdu lekarza', NULL, 'B'),
(23, 'W sytuacji złamania kości należy ją:', 'nastawić', 'naciągnąć i zmniejszyć ból', 'unieruchomić.', NULL, 'C'),
(24, 'Złamaną rękę należy:', 'nastawić', 'pozostawić bez zmian i podać środek przeciwbólowy', 'unieruchomić', NULL, 'C'),
(25, 'W przypadku obrażeń mięśni i stawów możemy zmniejszyć obrzęk w następujący sposób:', 'stosując zimny okład', 'stosując ciepły kompres', 'bandażując opatrunkiem elastycznym', NULL, 'A'),
(26, 'Jeżeli u poszkodowanego podejrzewamy uszkodzenie kręgosłupa, to należy:', 'usadzić go w pozycji półleżącej', 'położyć go w pozycji bocznej ustalonej', 'nie ruszać go i czekać na przybycie służb medycznych', NULL, 'C'),
(27, 'W razie podejrzenia uszkodzenia kręgosłupa na odcinku szyjnym należy:', 'ułożyć głowę w pozycji bocznej', 'unieruchomić głowę', 'nie ruszać poszkodowanego do czasu przyjazdu lekarza.', NULL, 'B'),
(28, 'Objawy, które mogą wskazywać na uszkodzenie kręgosłupa to:', 'zaburzenia czucia powyżej złamania', 'mechanizm urazu', 'dreszcze', NULL, 'B'),
(29, 'W przypadku krwawienia z nosa należy:', 'pochylić głowę krwawiącego mocno do przodu, ucisnąć skrzydełka nosa,', 'położyć zimny kompres na czoło', 'odchylić głowę do tyłu i położyć zimny kompres na kark', NULL, 'B'),
(30, 'Opaskę uciskową należy stosować w wypadku:', 'zmiażdżenia lub oderwania kończyny', 'zranienia głowy', 'każdej rany', NULL, 'A'),
(31, 'Przy silnie krwawiącej ranie w pierwszej kolejności należy:', 'napoić osobę poszkodowaną', 'ją zdezynfekować', 'zatamować krwawienie', NULL, 'C'),
(32, 'Na krwawiącą ranę przed jej zabandażowaniem należy położyć:', 'watę', 'jałową gazę', 'ligninę', NULL, 'B'),
(33, 'Do opatrywania krwawiących ran stosuje się:', 'opatrunek uciskowy z gazy lub płótna oraz bandaż', 'jodynę lub gencjanę', 'tylko jałową gazę', NULL, 'A'),
(34, 'Jeżeli w ranie znajduje się ostry przedmiot, należy:', 'natychmiast go wyjąć', 'pozostawić go w ranie', 'wyjąć go i nałożyć jałowy opatrunek', NULL, 'B'),
(35, 'Skaleczenia i mniejsze rany można przemyć:', 'jodyną', 'wodą utlenioną', 'wodą z kranu', NULL, 'C'),
(36, 'W przypadku zakrztuszenia osoby dorosłej pierwszą pomoc rozpoczynamy od:', 'wygarnięcia ręką zawartości jamy ustnej', 'uniesienia rąk do góry', 'uderzeń w okolicę między łopatkową', NULL, 'C'),
(37, 'Które objawy, wymienione poniżej są charakterystyczne dla oparzenia I stopnia:', 'ból i zaczerwienie skóry', 'osmalenie rzęs i brwi', 'pojawienie się pęcherzy z płynem surowiczym', NULL, 'A'),
(38, 'Które objawy, wymienione poniżej są charakterystyczne dla oparzenia II stopnia:', 'ból i zaczerwienie skóry', 'osmalenie rzęs i brwi', 'pojawienie się pęcherzy z płynem surowiczym', NULL, 'C'),
(39, 'Pierwsza pomoc w przypadku ciała obcego w oku polega na:', 'przepłukaniu oka kroplami do oczu', 'płukaniu czystą wodą, kierując strumień od nosa na zewnątrz oka', 'usunięciu ciała obcego, poprzez masowanie powieki', NULL, 'B'),
(40, 'Po upadku z roweru chłopiec na krótko stracił przytomność. Po jej odzyskaniu nie pamięta wydarzeń bezpośrednio poprzedzających uraz. Jaka może być tego przyczyna:', 'cierpi na zaniki pamięci', 'fizjologiczna odpowiedź na stres', 'doznał urazu głowy i wstrząśnienia mózgu', NULL, 'C'),
(41, 'Użycie pasów bezpieczeństwa w nowoczesnych pojazdach samochodowych ma na celu zmniejszenie ryzyka zgonów:', 'o 90%', 'o 70%', 'o 50%', NULL, 'A'),
(42, 'Aparat AED posiada wymienione poniżej elementy oprócz:', 'łyżki do wykonania defibrylacji', 'moduł analizujący rytm serca', 'system poleceń głosowych', 'przyklejane elektrody', 'A'),
(43, 'Po wykonaniu defibrylacji metodą zautomatyzowaną, urządzenie AED pracujące zgodnie z wytycznymi powinno zalecić:', 'ocenę tętna', 'ocenę oddechu', 'podjęcie resuscytacji krążeniowo-oddechowej', 'ocenę oznak krążenia', 'C'),
(44, 'Szyny Kramera służą do:', 'unieruchomienia złamanej kończyny', 'usztywnienia pasa lędźwiowego kręgosłupa', 'tamowania krwotoków wewnętrznych', 'żadna z powyższych odpowiedzi', 'A'),
(45, 'W każdej apteczce powinny znajdować się następujące środki', 'odkażające rany i ręce', 'hemostatyki tamujące krew', 'podstawowe leki przeciwbólowe', NULL, 'A'),
(46, 'Chusta trójkątna może być stosowana w celu:', 'unieruchomienia złamania przedramienia', 'jako temblak podtrzymujący zranioną kończynę', 'jako zaimprowizowany opatrunek', 'wszystkie odpowiedzi są prawidłowe', 'B'),
(47, 'Osobę we wstrząsie zabezpieczamy przed wychłodzeniem kocem termicznym ( folią NRC), który ułożyć należy:', 'kolor nie ma znaczenia, ważne jest szczelne owinięcie poszkodowanego', 'złotą stroną na zewnątrz', 'srebrną stroną na zewnątrz', 'folia NRC jest wykorzystywana wyłącznie przez personel medyczny', 'D'),
(48, 'Folia NRC zwana potocznie kocem termicznym służy do:', 'zapewnienia czystego podłoża dla poszkodowane', 'zapewnienia komfortu termicznego osobie nieprzytomnej', 'służy do zabezpieczenia odmrożeń', 'prawidłowa jest odpowiedź b i c', 'A'),
(49, '„Łańcuch przeżycia” jest modelem złożonym z kilku ogniw, które rozwijają działania ratunkowe o coraz wyższym stopniu zaawansowania [1], w celu zapewnienia osobie znajdującej się w stanie zagrożenia życia szybkiej i skutecznej pomocy.[2]', 'zdanie 1 i 2 prawdziwe, bez związku przyczynowo-skutkowego', 'zdanie 1 i 2 prawdziwe powiązane związkiem przyczynowo-skutkowym', 'zdanie 1 fałszywe, zdanie 2 prawdziwe', 'zdanie 1 i 2 fałszywe', 'B'),
(50, 'Termin „podtopienie ” należy rozumieć jako:', 'przypadek przeżycia osoby, u której doszło do duszenia się w wyniku zanurzenia w wodzie', 'gwałtowną reakcję organizmu w zetknięciu z lodowatą wodą', '„nurkowy odruch ssaków” w zetknięciu z wodą', 'niespodziewane zachłyśnięcie podczas zanurzenia w wodzie', 'A'),
(51, 'Osoba porażona prądem o wysokim napięciu może doznać:', 'znacznych oparzeń', 'poważnych zaburzeń rytmu serca', 'złamania kości', 'prawidłowa odpowiedź to a i b', 'D'),
(52, 'W jakich okolicznościach należy unikać bezpośredniej wentylacji usta-usta:', 'podejrzenie zatrucie cyjankami', 'podejrzenie zatrucie tlenkiem węgla', 'podejrzenie zatrucia środkami fosforoorganicznymi', 'wszystkie prawdziwe', 'D'),
(53, 'U ofiary rażenia piorunem zalecanym postępowaniem ratunkowym jest:', 'priorytetowe wezwanie straży pożarnej', 'podjęcie resuscytacji krążeniowo-oddechowej', 'natychmiastowe ochłodzenie ciała', 'nie należy podejmować jakichkolwiek czynności przed przybyciem pogotowia ratunkowego', 'B'),
(54, 'Pierwszy krok w postępowaniu z ofiarą zatrucia czadem to:', 'przeprowadzenie badania wstępnego', 'zebranie wywiadu', 'ocena ABC', 'usunięcie ofiary z toksycznej atmosfery', 'D'),
(55, 'Podejrzewając zawał serca u osoby dorosłej należy podjąć wymienione niżej czynności z wyjątkiem:', 'zmierzyć tętno i ciśnienie', 'ułożyć chorego w pozycji leżącej na wznak i unieść kończyny dolne', 'zapewnić dostęp świeżego powietrza', 'podać aspirynę jeżeli ratowany jest przytomny', 'B'),
(56, 'W odpowiedzi na zagrażającą hipotermię reakcją obronną organizmu będzie:', 'zwolnienie metabolizmu', 'zwolnienie oddychania i zwolnienie akcji serca', 'zatrzymanie oddechu i drżenie mięśni', 'wzrost napięcia mięśni szkieletowych i drżenie mięśniowe', 'D'),
(57, 'Jakie jest prawidłowe postępowanie w przypadku podejrzenia udaru cieplnego:', 'intensywne schładzanie przez zanurzenie ciała w lodowatej kąpieli', 'intensywne schładzanie przez spryskiwanie ciała letnią wodą i owiewanie chłodnym powietrzem', 'natychmiastowe podanie leków przeciwgorączkowych', 'prawidłowe a i c', 'B'),
(58, 'Przystępując do udzielenia pomocy osobie wykazującej pot, ból w klatce piersiowej, osłabienie, problem z oddechem a nawet utratę przytomności w pierwszej kolejności:', 'udam się w poszukiwaniu AED bo to urządzenie bardzo pomaga przy zawale', 'każę odsunąć się od osoby chorej i rozpocznę RKO', 'poproszę o pomoc osoby w pobliżu i będę oczekiwał na dalszy rozwój sytuacji', 'wszystkie odpowiedzi nie są poprawne', 'D'),
(59, 'Jeżeli dotąd zdrowe niemowlę (6 miesięczne) zaczyna nagle oddychać z trudem, wydaje dziwne dźwięki, sinieje na twarzy - to podejrzewasz:', 'napad drgawek', 'zadławienie', 'odruch „wstrzymania oddechu”', 'zapalenie oskrzeli', 'B'),
(60, 'Twój kolega z pracy doznał rany ciętej przedramienia, na skutek zranienia kawałkiem czystego szkła. Wskaż jakie postępowanie jest zalecane w ramach pierwszej pomocy:', 'powierzchnię wokół rany należy przemyć alkoholem', 'ranę należy przemyć woda utlenioną', 'należy zastosować opatrunek uciskowy', 'należy założyć czysty opatrunek na ranę uważając aby nie naruszyć ewentualnego ciała obcego', 'D'),
(61, 'Jesteś świadkiem wypadku drogowego z udziałem pieszego, który został potrącony przez samochód. Ofiara potrącenia leży na skraju jezdni i nie może wstać. Co powinieneś zrobić w tej sytuacji:', 'pomóc stanąć poszkodowanemu na nogi', 'przesunąć samodzielnie poszkodowanego na chodnik', 'nie ruszasz poszkodowanego ponieważ podejrzewasz uraz kręgosłupa', 'ułożyć poszkodowanego w pozycji bezpiecznej aby się nie zachłysnął', 'C'),
(62, 'Jesteś świadkiem wypadku drogowego, podczas którego samochód osobowy uderzył w łup linii wysokiego napięcia. Kierowca siedzący wewnątrz pojazdu sprawia wrażenie nieprzytomnego, a zerwane druty iskrząc zwisają nad pojazdem:', 'z bezpiecznej odległości wezwiesz straż pożarną i pogotowie energetyczne', 'wyłączysz stacyjkę samochodu, aby nie doszło do wybuchu paliwa', 'postarasz się odsunąć druty drewnianym narzędziem i wydobyć poszkodowanego', 'założysz rękawice ochronne i ocenisz oddech i tętno ofiary', 'A'),
(63, 'Jesteś świadkiem napadu drgawkowego u ucznia w szkole. Poza tobą są inni świadkowie. Co robisz?', 'starasz się ochronić głowę chłopca przed urazami', 'przeciwdziałasz drganiom ciała', 'szukasz sprzętu w celu zabezpieczenia przed przygryzieniem języka', 'układasz chłopca w pozycji bocznej i odchodzisz aby zatelefonować po pomoc', 'A'),
(64, 'Wskaż twierdzenie prawdziwe. W przypadku podtopienia:', 'wstępne leczenie zależy od tego czy woda była słodka czy słona', 'u ofiary tonięcia zatrzymanie oddechu zwykle poprzedza zatrzymanie krążenia', 'może dojść do wychłodzenia organizmu nawet w klimacie śródziemnomorskim', 'prawdziwe b i c', 'D'),
(65, 'Podczas przerwy 12 – letni chłopiec zakrztusił się kęsem jabłka. Jest przytomny, nie może mówić, ma trudności w oddychaniu. Jakie czynności należy u niego wykonać:', '5 uderzeń między łopatkami, naprzemiennie z 5 uciśnięciami nadbrzusza do momentu usunięcia ciała obcego lub utraty przytomności', '5 uderzeń między łopatkami, do momentu usunięcia ciała obcego, lub utraty przytomności', '5 uciśnięć nadbrzusza do momentu usunięcia ciała obcego lub utraty przytomności', 'zachęcać do kaszlu do momentu usunięcia ciała obcego lub utraty przytomności', 'A'),
(66, 'Udzielając pomocy 4 letniemu dziecku, u którego przed chwilą doszło do oparzenia gorącą wodą kończyn dolnych należy w pierwszej kolejności:', 'posmarować oparzone miejsce maścią', 'zastosować na oparzone miejsce środek odkażający ( np. Panthenol, spirytus)', 'schłodzić miejsce oparzenia zimną wodą', 'założyć jałowy opatrunek', 'C'),
(67, 'W zatłoczonym sklepiku szkolnym jedna z uczennic osunęła się nagle na ziemię, prawdopodobnie zemdlała. Jakie będzie postępowanie w tym przypadku?', 'wezwanie pomocy', 'zapewnienie dostępu świeżego powietrza', 'zastosowanie pozycji poziomej z uniesionymi nogami', 'prawidłowe b i c', 'D'),
(68, 'Poszkodowany w czasie wypadku doznał wielu obrażeń. Które z podanych objawów, bądź obrażeń świadczą o zagrożeniu życia?', 'złamanie kończyny górnej', 'ból w okolicy lędźwiowej', 'blada, chłodna i spocona skóra', 'zwichnięcie barku z jego stłuczeniem', 'C'),
(69, 'Chłopiec po upadku z drabiny z wysokości 3 m leży na ziemi i jęczy. Co należy zrobić w pierwszej kolejności:', 'odciągnąć go w bezpieczne miejsce', 'próbować postawić na nogi', 'podać środek przeciw bólowy w tabletce', 'nie ruszać do czasu przybycia zespołu ratownictwa medycznego', 'D'),
(70, 'Kierowca samochodu osobowego po zderzeniu z drzewem pozostaje w pozycji siedzącej w aucie. Co może usprawiedliwiać szybkie wydobycie mężczyzny, zanim przybędą służby ratunkowe?', 'złamanie kości udowej i ramienia', 'nielogiczne odpowiedzi na pytania', 'konieczność podjęcia sztucznego oddychania', 'zgłoszenie przez poszkodowanego znacznego bólu pleców', 'C');

--
-- Indeksy dla zrzutów tabel
--

--
-- Indeksy dla tabeli `quiz_questions`
--
ALTER TABLE `quiz_questions`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `quiz_questions`
--
ALTER TABLE `quiz_questions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=71;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
