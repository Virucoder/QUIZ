<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Quiz</title>
    <link rel="stylesheet" href="styles.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

</head>
<body>
    <body class="d-flex justify-content-center align-items-center vh-100">

    <form id="quizForm" class="text-center p-4 bg-light rounded shadow" action="quiz.php" method="POST">

        <?php
        session_start();
        require 'db.php';

        $stmt = $conn->query("SELECT * FROM quiz_questions ORDER BY RAND() LIMIT 20");
        $questions = $stmt->fetchAll(PDO::FETCH_ASSOC);
        $_SESSION['quiz'] = $questions;


        foreach ($questions as $index => $question) {
            echo "<div class='quiz-question'>";

            echo "<p><strong>" . ($index + 1) . ". {$question['question']}</strong></p>";

            foreach (['A', 'B', 'C'] as $option) {
                echo "<label>";
                echo "<input type='radio' name='q{$question['id']}' value='{$option}' required> ";
                echo "<strong>" . strtolower($option) . ")</strong> {$question['answer_' . strtolower($option)]}";
                echo "</label><br>";
            }

            echo "</div>";
        }
        ?> <br>
        <button type="submit" class="mybutton btn btn-primary mt-3">Sprawdź odpowiedzi</button>
    </form>

    <script src="script.js"></script>
</body>
</html>



