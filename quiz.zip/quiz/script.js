document.getElementById('quizForm').addEventListener('submit', function(event) {
    event.preventDefault();
    let score = 0;
    let quizData = <?php echo json_encode($_SESSION['quiz']); ?>;

    quizData.forEach((question, index) => {
        let selected = document.querySelector(`input[name="q${question.id}"]:checked`);
        if (selected) {
            let answer = selected.value;
            if (answer === question.correct_answer) {
                score++;
                selected.parentElement.classList.add('correct');
            } else {
                selected.parentElement.classList.add('wrong');
            }
        }
    });

    alert(`Twój wynik: ${score} / ${quizData.length}`);
});
