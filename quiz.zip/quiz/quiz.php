<?php
session_start();
require 'db.php';

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $score = 0;
    $results = [];

    foreach ($_POST as $key => $userAnswer) {
        if (strpos($key, "q") === 0) {
            $questionId = intval(substr($key, 1));
            $stmt = $conn->prepare("SELECT question, correct_answer, answer_a, answer_b, answer_c FROM quiz_questions WHERE id = ?");
            $stmt->execute([$questionId]);
            $questionData = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($questionData) {
                $isCorrect = ($userAnswer === $questionData['correct_answer']);
                if ($isCorrect) $score++;

                $results[] = [
                    'question' => $questionData['question'],
                    'user_answer' => $userAnswer,
                    'correct_answer' => $questionData['correct_answer'],
                    'is_correct' => $isCorrect
                ];
            }
        }
    }
    ?>

    <!DOCTYPE html>
    <html lang="pl">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Wyniki quizu</title>
        <link rel="stylesheet" href="styles.css">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

    </head>
    <body>
        <body class="d-flex justify-content-center align-items-center vh-100">

        <h1>Twój wynik: <?= $score ?> / <?= count($_SESSION['quiz']) ?></h1>

        <div id="results" class="text-center">

    <?php foreach ($results as $result): ?>
        <div class="<?= $result['is_correct'] ? 'correct' : 'wrong' ?>">
            <p><strong>Pytanie:</strong> <?= $result['question'] ?></p>
            <p><strong>Twoja odpowiedź:</strong> <?= $result['user_answer'] ?></p>
            <?php if (!$result['is_correct']): ?>
                <p class="correct-answer"><strong>Poprawna odpowiedź:</strong> <?= $result['correct_answer'] ?></p>
            <?php endif; ?>

        </div>
    <?php endforeach; ?>
</div>

    </body>
    </html>

    <?php
}
?>

